/* =============================================
   VOICER STUDIO — App Logic
   ============================================= */

'use strict';

// ===== UTILITIES =====
const $ = id => document.getElementById(id);
const on = (el, ev, fn) => el && el.addEventListener(ev, fn);

function showStatus(id, msg, type = 'info', duration = 4000) {
    const el = $(id);
    if (!el) return;
    el.textContent = `${type === 'success' ? '✓' : type === 'error' ? '✕' : '●'}  ${msg}`;
    el.className = `status-bar show ${type}`;
    if (duration > 0) {
        setTimeout(() => {
            el.classList.remove('show');
        }, duration);
    }
}

function formatBytes(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

function formatTime(seconds) {
    const m = Math.floor(seconds / 60).toString().padStart(2, '0');
    const s = Math.floor(seconds % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
}

// ===== NAVIGATION =====
const heroTitles = {
    tts: ['Text to Speech', 'Convert written words into natural-sounding voice with precision control'],
    vtt: ['Speech to Text', 'Transcribe audio to text in real time with high accuracy'],
    convert: ['Voice Converter', 'Transform audio between formats with professional quality'],
    enhance: ['Voice Enhancement', 'Remove noise and sculpt your audio with studio-grade EQ effects']
};

document.querySelectorAll('.nav-pill').forEach(pill => {
    on(pill, 'click', () => {
        const tab = pill.dataset.tab;

        document.querySelectorAll('.nav-pill').forEach(p => p.classList.remove('active'));
        document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));

        pill.classList.add('active');
        $(`panel-${tab}`).classList.add('active');

        const [title, sub] = heroTitles[tab];
        $('heroTitle').textContent = title;
        $('heroSub').textContent = sub;
    });
});


// =============================================
// TEXT TO SPEECH
// =============================================
(function initTTS() {
    const textarea   = $('ttsText');
    const voiceSel   = $('ttsVoice');
    const speedSlider= $('ttsSpeed');
    const pitchSlider= $('ttsPitch');
    const volSlider  = $('ttsVol');
    const speedVal   = $('ttsSpeedVal');
    const pitchVal   = $('ttsPitchVal');
    const volVal     = $('ttsVolVal');
    const genBtn     = $('ttsGenerate');
    const stopBtn    = $('ttsStop');
    const charCount  = $('ttsCharCount');
    const waveBars   = $('ttsWaveBars');
    const waveIdle   = document.querySelector('.waveform-idle');

    let voices = [];
    let currentUtterance = null;
    let isPlaying = false;

    // Char counter
    function updateCharCount() {
        charCount.textContent = textarea.value.length.toLocaleString();
    }
    on(textarea, 'input', updateCharCount);
    updateCharCount();

    // Load voices
    function loadVoices() {
        voices = speechSynthesis.getVoices();
        voiceSel.innerHTML = voices.map((v, i) =>
            `<option value="${i}">${v.name} — ${v.lang}</option>`
        ).join('');
    }
    loadVoices();
    if (typeof speechSynthesis !== 'undefined' && speechSynthesis.onvoiceschanged !== undefined) {
        speechSynthesis.onvoiceschanged = loadVoices;
    }

    // Sliders
    on(speedSlider, 'input', () => speedVal.textContent = parseFloat(speedSlider.value).toFixed(1) + '×');
    on(pitchSlider, 'input', () => pitchVal.textContent = parseFloat(pitchSlider.value).toFixed(1));
    on(volSlider,   'input', () => volVal.textContent = volSlider.value + '%');

    // Waveform
    function buildWaveform() {
        waveBars.innerHTML = '';
        for (let i = 0; i < 40; i++) {
            const bar = document.createElement('div');
            bar.className = 'waveform-bar';
            bar.style.height = (Math.random() * 40 + 8) + 'px';
            bar.style.animationDelay = (Math.random() * 1) + 's';
            bar.style.animationDuration = (0.6 + Math.random() * 0.8) + 's';
            waveBars.appendChild(bar);
        }
        waveBars.style.display = 'flex';
        if (waveIdle) waveIdle.style.display = 'none';
    }

    function resetWaveform() {
        waveBars.style.display = 'none';
        if (waveIdle) waveIdle.style.display = '';
    }

    // Generate speech
    on(genBtn, 'click', () => {
        const text = textarea.value.trim();
        if (!text) {
            showStatus('ttsStatus', 'Please enter some text first.', 'error');
            return;
        }

        if (speechSynthesis.speaking) {
            speechSynthesis.cancel();
        }

        const utterance = new SpeechSynthesisUtterance(text);
        const selectedVoice = voices[parseInt(voiceSel.value)];
        if (selectedVoice) utterance.voice = selectedVoice;
        utterance.rate   = parseFloat(speedSlider.value);
        utterance.pitch  = parseFloat(pitchSlider.value);
        utterance.volume = parseInt(volSlider.value) / 100;

        utterance.onstart = () => {
            isPlaying = true;
            buildWaveform();
            genBtn.disabled = true;
            showStatus('ttsStatus', 'Speaking…', 'info', 0);
        };

        utterance.onend = () => {
            isPlaying = false;
            resetWaveform();
            genBtn.disabled = false;
            showStatus('ttsStatus', 'Finished speaking.', 'success');
        };

        utterance.onerror = (e) => {
            isPlaying = false;
            resetWaveform();
            genBtn.disabled = false;
            showStatus('ttsStatus', 'Error: ' + e.error, 'error');
        };

        currentUtterance = utterance;
        speechSynthesis.speak(utterance);
    });

    on(stopBtn, 'click', () => {
        speechSynthesis.cancel();
        isPlaying = false;
        resetWaveform();
        genBtn.disabled = false;
        showStatus('ttsStatus', 'Playback stopped.', 'info');
    });
})();


// =============================================
// VOICE TO TEXT
// =============================================
(function initVTT() {
    const recordBtn   = $('vttRecord');
    const stopBtn     = $('vttStopRec');
    const transcript  = $('vttTranscript');
    const copyBtn     = $('vttCopy');
    const dlTxtBtn    = $('vttDownloadTxt');
    const clearBtn    = $('vttClear');
    const langSel     = $('vttLang');
    const micRing     = $('micRing');
    const micStatus   = $('micStatus');
    const micTimer    = $('micTimer');
    const continuousToggle = $('vttContinuous');
    const interimToggle    = $('vttInterim');

    let recognition    = null;
    let isRecording    = false;
    let finalTranscript = '';
    let timerInterval  = null;
    let seconds        = 0;
    let isContinuous   = false;
    let showInterim    = true;

    // Check support
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
        showStatus('vttStatus', 'Speech recognition is not supported in this browser. Try Chrome or Edge.', 'error', 0);
        recordBtn.disabled = true;
        return;
    }

    // Toggles
    on(continuousToggle, 'click', () => {
        isContinuous = !isContinuous;
        continuousToggle.classList.toggle('active', isContinuous);
    });

    on(interimToggle, 'click', () => {
        showInterim = !showInterim;
        interimToggle.classList.toggle('active', showInterim);
    });

    function updateTranscriptDisplay(interim = '') {
        const placeholder = transcript.querySelector('.transcript-placeholder');

        if (finalTranscript || interim) {
            if (placeholder) placeholder.style.display = 'none';
            transcript.innerHTML = `<div class="transcript-text">${finalTranscript}<span class="transcript-interim">${interim}</span></div>`;
        } else {
            if (placeholder) {
                placeholder.style.display = 'flex';
                transcript.innerHTML = '';
                transcript.appendChild(placeholder);
            }
        }
        transcript.scrollTop = transcript.scrollHeight;
    }

    function startTimer() {
        seconds = 0;
        micTimer.textContent = formatTime(0);
        micTimer.classList.add('active');
        timerInterval = setInterval(() => {
            seconds++;
            micTimer.textContent = formatTime(seconds);
        }, 1000);
    }

    function stopTimer() {
        clearInterval(timerInterval);
        micTimer.classList.remove('active');
    }

    function startRecording() {
        recognition = new SpeechRecognition();
        recognition.lang = langSel.value;
        recognition.continuous = isContinuous;
        recognition.interimResults = showInterim;

        recognition.onstart = () => {
            isRecording = true;
            recordBtn.disabled = true;
            recordBtn.classList.add('recording');
            stopBtn.disabled = false;
            micRing.classList.add('recording');
            micStatus.textContent = 'Recording…';
            startTimer();
            showStatus('vttStatus', 'Microphone active — speak clearly.', 'info', 0);
        };

        recognition.onresult = (event) => {
            let interim = '';
            for (let i = event.resultIndex; i < event.results.length; i++) {
                const result = event.results[i];
                if (result.isFinal) {
                    finalTranscript += result[0].transcript + ' ';
                } else {
                    interim += result[0].transcript;
                }
            }
            updateTranscriptDisplay(showInterim ? interim : '');
        };

        recognition.onend = () => {
            if (isRecording && isContinuous) {
                recognition.start();
                return;
            }
            stopRecordingUI();
        };

        recognition.onerror = (event) => {
            let msg = 'Recognition error.';
            if (event.error === 'no-speech') msg = 'No speech detected. Try again.';
            if (event.error === 'audio-capture') msg = 'Microphone not accessible.';
            if (event.error === 'not-allowed') msg = 'Microphone permission denied.';
            showStatus('vttStatus', msg, 'error');
            stopRecordingUI();
        };

        recognition.start();
    }

    function stopRecordingUI() {
        isRecording = false;
        recordBtn.disabled = false;
        recordBtn.classList.remove('recording');
        stopBtn.disabled = true;
        micRing.classList.remove('recording');
        micStatus.textContent = 'Ready to record';
        stopTimer();
        updateTranscriptDisplay();
        showStatus('vttStatus', 'Recording stopped.', 'success');
    }

    on(recordBtn, 'click', startRecording);

    on(stopBtn, 'click', () => {
        isRecording = false;
        if (recognition) recognition.stop();
    });

    on(copyBtn, 'click', () => {
        if (!finalTranscript) return;
        navigator.clipboard.writeText(finalTranscript.trim()).then(() => {
            showStatus('vttStatus', 'Transcript copied to clipboard.', 'success');
        });
    });

    on(dlTxtBtn, 'click', () => {
        if (!finalTranscript) return;
        const blob = new Blob([finalTranscript.trim()], { type: 'text/plain' });
        const url  = URL.createObjectURL(blob);
        const a    = document.createElement('a');
        a.href = url;
        a.download = `voicer-transcript-${Date.now()}.txt`;
        a.click();
        URL.revokeObjectURL(url);
        showStatus('vttStatus', 'Transcript downloaded.', 'success');
    });

    on(clearBtn, 'click', () => {
        finalTranscript = '';
        const placeholder = document.createElement('div');
        placeholder.className = 'transcript-placeholder';
        placeholder.innerHTML = `
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/>
                <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
                <line x1="12" y1="19" x2="12" y2="23"/>
                <line x1="8" y1="23" x2="16" y2="23"/>
            </svg>
            <p>Start recording to see your transcript appear here in real time</p>`;
        transcript.innerHTML = '';
        transcript.appendChild(placeholder);
        showStatus('vttStatus', 'Transcript cleared.', 'info');
    });
})();


// =============================================
// VOICE CONVERTER
// =============================================
(function initConverter() {
    const dropZone   = $('converterDrop');
    const fileInput  = $('converterFile');
    const preview    = $('converterPreview');
    const audio      = $('converterAudio');
    const fileName   = $('converterFileName');
    const fileMeta   = $('converterFileMeta');
    const formatSel  = $('converterFormat');
    const convertBtn = $('converterConvert');
    const dlBtn      = $('converterDownload');
    const progress   = $('converterProgress');
    const fill       = $('converterFill');
    const label      = $('converterLabel');

    let sourceFile = null;
    let convertedBlob = null;

    function handleFile(file) {
        if (!file || !file.type.startsWith('audio/')) {
            showStatus('converterStatus', 'Please upload an audio file.', 'error');
            return;
        }
        sourceFile = file;
        fileName.textContent = file.name.length > 30 ? file.name.substring(0, 30) + '…' : file.name;
        fileMeta.textContent = `${formatBytes(file.size)} · ${file.type.split('/')[1].toUpperCase()}`;
        audio.src = URL.createObjectURL(file);
        preview.style.display = 'block';
        convertBtn.disabled = false;
        convertedBlob = null;
        dlBtn.disabled = true;
        showStatus('converterStatus', 'File loaded. Ready to convert.', 'success');
    }

    // Drag & drop
    on(dropZone, 'click', () => fileInput.click());
    on(dropZone, 'dragover', e => { e.preventDefault(); dropZone.classList.add('dragging'); });
    on(dropZone, 'dragleave', () => dropZone.classList.remove('dragging'));
    on(dropZone, 'drop', e => {
        e.preventDefault();
        dropZone.classList.remove('dragging');
        handleFile(e.dataTransfer.files[0]);
    });
    on(fileInput, 'change', e => handleFile(e.target.files[0]));

    function animateProgress(targetPct, currentLabel) {
        label.textContent = currentLabel;
        let pct = 0;
        const interval = setInterval(() => {
            pct = Math.min(pct + 2, targetPct);
            fill.style.width = pct + '%';
            if (pct >= targetPct) clearInterval(interval);
        }, 20);
    }

    on(convertBtn, 'click', async () => {
        if (!sourceFile) return;

        progress.style.display = 'block';
        convertBtn.disabled = true;
        fill.style.width = '0%';
        showStatus('converterStatus', 'Converting…', 'info', 0);

        try {
            animateProgress(40, 'Reading audio…');

            const arrayBuffer = await sourceFile.arrayBuffer();
            const audioCtx = new (window.AudioContext || window.webkitAudioContext)({
                sampleRate: parseInt($('converterSampleRate').value)
            });

            animateProgress(70, 'Decoding audio…');
            const audioBuffer = await audioCtx.decodeAudioData(arrayBuffer);

            animateProgress(90, 'Encoding output…');

            const channels = parseInt($('converterChannels').value);
            convertedBlob = await audioBufferToWav(audioBuffer, channels);

            animateProgress(100, 'Done!');

            setTimeout(() => {
                progress.style.display = 'none';
                convertBtn.disabled = false;
                dlBtn.disabled = false;
                showStatus('converterStatus', 'Conversion complete! Ready to download.', 'success');
            }, 500);

            await audioCtx.close();
        } catch (err) {
            progress.style.display = 'none';
            convertBtn.disabled = false;
            showStatus('converterStatus', 'Error: ' + err.message, 'error');
        }
    });

    on(dlBtn, 'click', () => {
        if (!convertedBlob) return;
        const ext = formatSel.value;
        const url = URL.createObjectURL(convertedBlob);
        const a   = document.createElement('a');
        a.href = url;
        a.download = `voicer-converted.${ext}`;
        a.click();
        URL.revokeObjectURL(url);
        showStatus('converterStatus', 'Download started!', 'success');
    });
})();


// =============================================
// VOICE ENHANCER
// =============================================
(function initEnhancer() {
    const dropZone    = $('enhancerDrop');
    const fileInput   = $('enhancerFile');
    const preview     = $('enhancerPreview');
    const resultPrev  = $('enhancerResultPreview');
    const audio       = $('enhancerAudio');
    const resultAudio = $('enhancerResultAudio');
    const fileName    = $('enhancerFileName');
    const fileMeta    = $('enhancerFileMeta');
    const applyBtn    = $('enhancerApply');
    const dlBtn       = $('enhancerDownload');
    const progress    = $('enhancerProgress');
    const fill        = $('enhancerFill');
    const label       = $('enhancerLabel');

    // Slider labels
    const sliders = [
        ['noiseReduction', 'noiseVal',  v => v + '%'],
        ['bassBoost',      'bassVal',   v => (v > 0 ? '+' : '') + v + ' dB'],
        ['midRange',       'midVal',    v => (v > 0 ? '+' : '') + v + ' dB'],
        ['treble',         'trebleVal', v => (v > 0 ? '+' : '') + v + ' dB'],
        ['gainCtrl',       'gainVal',   v => (v > 0 ? '+' : '') + v + ' dB'],
    ];
    sliders.forEach(([sliderId, valId, fmt]) => {
        const slider = $(sliderId);
        const valEl  = $(valId);
        if (slider && valEl) {
            on(slider, 'input', () => valEl.textContent = fmt(slider.value));
        }
    });

    let sourceFile = null;
    let enhancedBlob = null;

    function handleFile(file) {
        if (!file || !file.type.startsWith('audio/')) {
            showStatus('enhancerStatus', 'Please upload an audio file.', 'error');
            return;
        }
        sourceFile = file;
        fileName.textContent = file.name.length > 30 ? file.name.substring(0, 30) + '…' : file.name;
        fileMeta.textContent = `${formatBytes(file.size)} · ${file.type.split('/')[1].toUpperCase()}`;
        audio.src = URL.createObjectURL(file);
        preview.style.display = 'block';
        resultPrev.style.display = 'none';
        applyBtn.disabled = false;
        dlBtn.disabled = true;
        enhancedBlob = null;
        showStatus('enhancerStatus', 'File loaded. Adjust settings and apply.', 'success');
    }

    on(dropZone, 'click', () => fileInput.click());
    on(dropZone, 'dragover', e => { e.preventDefault(); dropZone.classList.add('dragging'); });
    on(dropZone, 'dragleave', () => dropZone.classList.remove('dragging'));
    on(dropZone, 'drop', e => {
        e.preventDefault();
        dropZone.classList.remove('dragging');
        handleFile(e.dataTransfer.files[0]);
    });
    on(fileInput, 'change', e => handleFile(e.target.files[0]));

    function animateProgress(targetPct, currentLabel) {
        label.textContent = currentLabel;
        let pct = parseInt(fill.style.width) || 0;
        const interval = setInterval(() => {
            pct = Math.min(pct + 2, targetPct);
            fill.style.width = pct + '%';
            if (pct >= targetPct) clearInterval(interval);
        }, 20);
    }

    on(applyBtn, 'click', async () => {
        if (!sourceFile) return;

        progress.style.display = 'block';
        fill.style.width = '0%';
        applyBtn.disabled = true;
        showStatus('enhancerStatus', 'Processing…', 'info', 0);

        try {
            animateProgress(30, 'Loading audio…');

            const arrayBuffer = await sourceFile.arrayBuffer();
            const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            const audioBuffer = await audioCtx.decodeAudioData(arrayBuffer);

            animateProgress(60, 'Applying EQ and effects…');

            const processed = await processAudio(audioCtx, audioBuffer);

            animateProgress(90, 'Encoding result…');

            enhancedBlob = await audioBufferToWav(processed);
            const url = URL.createObjectURL(enhancedBlob);
            resultAudio.src = url;
            resultPrev.style.display = 'block';

            animateProgress(100, 'Complete!');

            setTimeout(() => {
                progress.style.display = 'none';
                applyBtn.disabled = false;
                dlBtn.disabled = false;
                showStatus('enhancerStatus', 'Effects applied! Preview below.', 'success');
            }, 500);

            await audioCtx.close();
        } catch (err) {
            progress.style.display = 'none';
            applyBtn.disabled = false;
            showStatus('enhancerStatus', 'Error: ' + err.message, 'error');
        }
    });

    async function processAudio(ctx, buffer) {
        const sampleRate = buffer.sampleRate;
        const channels   = buffer.numberOfChannels;
        const length     = buffer.length;

        const offline = new OfflineAudioContext(channels, length, sampleRate);
        const source  = offline.createBufferSource();

        // Apply voice effect (playback rate)
        const effect = $('voiceEffect').value;
        if (effect === 'deep')  source.playbackRate.value = 0.78;
        if (effect === 'high')  source.playbackRate.value = 1.45;

        source.buffer = buffer;

        // Bass
        const bass = offline.createBiquadFilter();
        bass.type = 'lowshelf';
        bass.frequency.value = 220;
        bass.gain.value = parseFloat($('bassBoost').value);

        // Mid
        const mid = offline.createBiquadFilter();
        mid.type = 'peaking';
        mid.frequency.value = 1000;
        mid.Q.value = 1;
        mid.gain.value = parseFloat($('midRange').value);

        // Treble
        const trebleFilter = offline.createBiquadFilter();
        trebleFilter.type = 'highshelf';
        trebleFilter.frequency.value = 3500;
        trebleFilter.gain.value = parseFloat($('treble').value);

        // Gain
        const gainNode = offline.createGain();
        gainNode.gain.value = Math.pow(10, parseFloat($('gainCtrl').value) / 20);

        // Noise reduction — high-pass to cut rumble based on setting
        const noiseLevel = parseInt($('noiseReduction').value);
        const hpFilter = offline.createBiquadFilter();
        hpFilter.type = 'highpass';
        hpFilter.frequency.value = noiseLevel * 0.8; // 0–80Hz cutoff

        // Echo / reverb effect
        let effectNode = null;
        if (effect === 'echo' || effect === 'stadium') {
            const convolver = offline.createConvolver();
            const impulseLen = effect === 'stadium' ? sampleRate * 2 : sampleRate * 0.5;
            const impulse = offline.createBuffer(2, impulseLen, sampleRate);
            for (let ch = 0; ch < 2; ch++) {
                const data = impulse.getChannelData(ch);
                for (let i = 0; i < impulseLen; i++) {
                    data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / impulseLen, 2);
                }
            }
            convolver.buffer = impulse;
            effectNode = convolver;
        }

        // Telephone effect
        if (effect === 'telephone') {
            const lp = offline.createBiquadFilter();
            lp.type = 'lowpass';
            lp.frequency.value = 3000;
            const hp = offline.createBiquadFilter();
            hp.type = 'highpass';
            hp.frequency.value = 300;
            source.connect(hpFilter);
            hpFilter.connect(hp);
            hp.connect(lp);
            lp.connect(bass);
        } else {
            source.connect(hpFilter);
            hpFilter.connect(bass);
        }

        bass.connect(mid);
        mid.connect(trebleFilter);

        if (effectNode) {
            trebleFilter.connect(effectNode);
            effectNode.connect(gainNode);
        } else {
            trebleFilter.connect(gainNode);
        }

        gainNode.connect(offline.destination);
        source.start(0);
        return await offline.startRendering();
    }

    on(dlBtn, 'click', () => {
        if (!enhancedBlob) return;
        const url = URL.createObjectURL(enhancedBlob);
        const a   = document.createElement('a');
        a.href = url;
        a.download = `voicer-enhanced-${Date.now()}.wav`;
        a.click();
        URL.revokeObjectURL(url);
        showStatus('enhancerStatus', 'Download started!', 'success');
    });
})();


// =============================================
// SHARED: Audio Buffer → WAV Blob
// =============================================
function audioBufferToWav(audioBuffer, targetChannels) {
    const numChannels = targetChannels || audioBuffer.numberOfChannels;
    const sampleRate  = audioBuffer.sampleRate;
    const format      = 1; // PCM
    const bitDepth    = 16;

    const bytesPerSample = bitDepth / 8;
    const blockAlign     = numChannels * bytesPerSample;

    const samples = [];
    for (let ch = 0; ch < numChannels; ch++) {
        samples.push(audioBuffer.getChannelData(Math.min(ch, audioBuffer.numberOfChannels - 1)));
    }

    const dataLength  = audioBuffer.length * blockAlign;
    const buffer      = new ArrayBuffer(44 + dataLength);
    const view        = new DataView(buffer);

    const writeStr = (offset, str) => {
        for (let i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i));
    };

    writeStr(0, 'RIFF');
    view.setUint32(4, 36 + dataLength, true);
    writeStr(8, 'WAVE');
    writeStr(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, format, true);
    view.setUint16(22, numChannels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * blockAlign, true);
    view.setUint16(32, blockAlign, true);
    view.setUint16(34, bitDepth, true);
    writeStr(36, 'data');
    view.setUint32(40, dataLength, true);

    let offset = 44;
    for (let i = 0; i < audioBuffer.length; i++) {
        for (let ch = 0; ch < numChannels; ch++) {
            const s = Math.max(-1, Math.min(1, samples[ch][i]));
            view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
            offset += 2;
        }
    }

    return new Blob([buffer], { type: 'audio/wav' });
}
